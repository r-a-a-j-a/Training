import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class TestBcrypt {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String hash = "$2a$10$wYONj0a9U.O205m0Fh5E.e2qHlkYq0Q9p.L2y7A10cE4Xk9o8Sj6S";
        System.out.println("Matches 'admin123': " + encoder.matches("admin123", hash));
        System.out.println("Matches 'admin': " + encoder.matches("admin", hash));
        System.out.println("Matches 'password': " + encoder.matches("password", hash));
    }
}
