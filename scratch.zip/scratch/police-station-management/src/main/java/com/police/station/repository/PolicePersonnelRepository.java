package com.police.station.repository;

import com.police.station.model.PersonnelStatus;
import com.police.station.model.PolicePersonnel;
import com.police.station.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PolicePersonnelRepository extends JpaRepository<PolicePersonnel, Long> {
    Optional<PolicePersonnel> findByPoliceNumber(String policeNumber);

    Optional<PolicePersonnel> findByIfhrmsNumber(String ifhrmsNumber);

    Optional<PolicePersonnel> findByUser(User user);

    List<PolicePersonnel> findByStatus(PersonnelStatus status);
}
