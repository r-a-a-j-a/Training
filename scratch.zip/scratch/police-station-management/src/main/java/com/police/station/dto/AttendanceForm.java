package com.police.station.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.Map;

@Getter
@Setter
public class AttendanceForm {
    // Map of personnelId_date -> status (P, A, ML, EL, OD)
    // e.g., "1_2026-02-01" -> "P"
    private Map<String, String> attendanceMap;
}
