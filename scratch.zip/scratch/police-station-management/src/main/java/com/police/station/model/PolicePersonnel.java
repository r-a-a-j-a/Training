package com.police.station.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Table(name = "police_personnel")
@Getter
@Setter
@NoArgsConstructor
public class PolicePersonnel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String policeNumber;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private LocalDate dateOfEnrolment;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Designation designation;

    @Column(unique = true, nullable = false)
    private String ifhrmsNumber;

    private Double salary;

    private String nativePlace;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PersonnelStatus status = PersonnelStatus.PENDING_APPROVAL;

    // Leave Balances
    private int clBalance = 15; // Default 15 days
    private int mlBalance = 10;
    private int elBalance = 30;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private User user;
}
