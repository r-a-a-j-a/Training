package com.police.station.controller;

import com.police.station.model.Duty;
import com.police.station.model.PolicePersonnel;
import com.police.station.model.User;
import com.police.station.repository.DutyRepository;
import com.police.station.repository.PolicePersonnelRepository;
import com.police.station.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/staff")
public class StaffController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PolicePersonnelRepository personnelRepository;

    @Autowired
    private DutyRepository dutyRepository;

    private PolicePersonnel getLoggedInPersonnel(Authentication authentication) {
        String username = authentication.getName();
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            Optional<PolicePersonnel> personnelOpt = personnelRepository.findByUser(userOpt.get());
            if (personnelOpt.isPresent()) {
                return personnelOpt.get();
            }
        }
        return null;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model, Authentication authentication) {
        model.addAttribute("activeMenu", "dashboard");

        PolicePersonnel personnel = getLoggedInPersonnel(authentication);
        if (personnel != null) {
            model.addAttribute("personnel", personnel);

            // Fetch unread/new duties
            List<Duty> duties = dutyRepository.findByPersonnelOrderByDutyDateTimeDesc(personnel);
            long newDutiesCount = duties.stream().filter(d -> "ASSIGNED".equals(d.getStatus())).count();
            model.addAttribute("newDutiesCount", newDutiesCount);
        }

        return "staff/dashboard";
    }
}
