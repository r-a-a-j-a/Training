package com.police.station.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "duties")
@Getter
@Setter
@NoArgsConstructor
public class Duty {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "personnel_id", nullable = false)
    private PolicePersonnel personnel;

    @Column(nullable = false)
    private LocalDateTime dutyDateTime;

    @Column(nullable = false)
    private String reportingPlace;

    @Column(nullable = false)
    private String reportingOfficer;

    @Column(length = 1000)
    private String description;

    @Column(nullable = false)
    private String status = "ASSIGNED"; // ASSIGNED, COMPLETED
}
