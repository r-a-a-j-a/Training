package com.police.station.controller;

import com.police.station.model.PersonnelStatus;
import com.police.station.model.PolicePersonnel;
import com.police.station.model.User;
import com.police.station.repository.PolicePersonnelRepository;
import com.police.station.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminModulesController {

    @Autowired
    private PolicePersonnelRepository personnelRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // ================= TRANSFERRED PERSONNEL (Module 6) =================
    @GetMapping("/transferred")
    public String transferredPersonnel(Model model) {
        model.addAttribute("activeMenu", "transferred");
        List<PolicePersonnel> transferredList = personnelRepository.findByStatus(PersonnelStatus.TRANSFERRED);
        model.addAttribute("personnelList", transferredList);
        return "admin/transferred";
    }

    // ================= IN-OD / OUT-OD (Module 7) =================
    @GetMapping("/od")
    public String odPersonnel(Model model) {
        model.addAttribute("activeMenu", "od");
        List<PolicePersonnel> inOdList = personnelRepository.findByStatus(PersonnelStatus.IN_OD);
        List<PolicePersonnel> outOdList = personnelRepository.findByStatus(PersonnelStatus.OUT_OD);

        model.addAttribute("inOdList", inOdList);
        model.addAttribute("outOdList", outOdList);
        return "admin/od";
    }

    // ================= NEW MEMBER REQUESTS (Module 3) =================
    @GetMapping("/requests")
    public String newRequests(Model model) {
        model.addAttribute("activeMenu", "requests");
        List<PolicePersonnel> pendingList = personnelRepository.findByStatus(PersonnelStatus.PENDING_APPROVAL);
        model.addAttribute("pendingList", pendingList);
        return "admin/requests";
    }

    @PostMapping("/requests/approve/{id}")
    public String approveRequest(@PathVariable("id") Long id) {
        PolicePersonnel personnel = personnelRepository.findById(id).orElseThrow();
        personnel.setStatus(PersonnelStatus.ACTIVE);

        // Ensure user account is active
        if (personnel.getUser() == null) {
            User newUser = new User();
            newUser.setUsername(personnel.getPoliceNumber());
            newUser.setPassword(passwordEncoder.encode("welcome123")); // default password
            newUser.setRole("ROLE_STAFF");
            userRepository.save(newUser);
            personnel.setUser(newUser);
        }

        personnelRepository.save(personnel);
        return "redirect:/admin/requests?success=approved";
    }

    @PostMapping("/requests/reject/{id}")
    public String rejectRequest(@PathVariable("id") Long id) {
        PolicePersonnel personnel = personnelRepository.findById(id).orElseThrow();
        // Since it's rejected, we could either delete or mark as rejected. We'll delete
        // for simplicity.
        if (personnel.getUser() != null) {
            // Optional: delete user account as well
            userRepository.delete(personnel.getUser());
        }
        personnelRepository.delete(personnel);
        return "redirect:/admin/requests?success=rejected";
    }

    // ================= REPORTS & DASHBOARD (Module 10) =================
    @GetMapping("/reports")
    public String reportsDashboard(Model model) {
        model.addAttribute("activeMenu", "reports");

        long totalPersonnel = personnelRepository.count();
        long activeCount = personnelRepository.findByStatus(PersonnelStatus.ACTIVE).size();
        long inOdCount = personnelRepository.findByStatus(PersonnelStatus.IN_OD).size();
        long outOdCount = personnelRepository.findByStatus(PersonnelStatus.OUT_OD).size();
        long transferredCount = personnelRepository.findByStatus(PersonnelStatus.TRANSFERRED).size();

        model.addAttribute("totalPersonnel", totalPersonnel);
        model.addAttribute("activeCount", activeCount);
        model.addAttribute("inOdCount", inOdCount);
        model.addAttribute("outOdCount", outOdCount);
        model.addAttribute("transferredCount", transferredCount);

        return "admin/reports";
    }
}
