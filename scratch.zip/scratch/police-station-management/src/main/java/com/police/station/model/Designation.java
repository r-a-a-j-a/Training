package com.police.station.model;

public enum Designation {
    PC,
    GR_I_PC,
    HC,
    SSI,
    SI
}
