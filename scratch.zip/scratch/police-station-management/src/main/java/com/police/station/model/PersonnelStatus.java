package com.police.station.model;

public enum PersonnelStatus {
    ACTIVE,
    TRANSFERRED,
    IN_OD,
    OUT_OD,
    PENDING_APPROVAL
}
