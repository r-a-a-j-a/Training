package com.police.station.repository;

import com.police.station.model.LeaveRequest;
import com.police.station.model.PolicePersonnel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LeaveRequestRepository extends JpaRepository<LeaveRequest, Long> {
    List<LeaveRequest> findByPersonnelOrderByFromDateDesc(PolicePersonnel personnel);

    List<LeaveRequest> findByStatusOrderByFromDateDesc(String status);
}
