package com.police.station.controller;

import com.police.station.model.Duty;
import com.police.station.model.PersonnelStatus;
import com.police.station.model.PolicePersonnel;
import com.police.station.model.User;
import com.police.station.repository.DutyRepository;
import com.police.station.repository.PolicePersonnelRepository;
import com.police.station.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class DutyController {

    @Autowired
    private DutyRepository dutyRepository;

    @Autowired
    private PolicePersonnelRepository personnelRepository;

    @Autowired
    private UserRepository userRepository;

    private PolicePersonnel getLoggedInPersonnel(Authentication authentication) {
        String username = authentication.getName();
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            Optional<PolicePersonnel> personnelOpt = personnelRepository.findByUser(userOpt.get());
            if (personnelOpt.isPresent()) {
                return personnelOpt.get();
            }
        }
        return null;
    }

    // ================= ADMIN PATHS =================

    @GetMapping("/admin/duty")
    public String adminDutyList(Model model) {
        model.addAttribute("activeMenu", "duty");
        List<Duty> duties = dutyRepository.findAll();
        // in real scenario sort by date descending
        model.addAttribute("duties", duties);
        return "admin/duty";
    }

    @GetMapping("/admin/duty/new")
    public String showDutyForm(@RequestParam(required = false) Long personnelId, Model model) {
        model.addAttribute("activeMenu", "duty");

        Duty duty = new Duty();
        if (personnelId != null) {
            personnelRepository.findById(personnelId).ifPresent(duty::setPersonnel);
        }

        model.addAttribute("duty", duty);

        // Only active personnel can be assigned duties (Exclude TRANFERRED, IN_OD,
        // OUT_OD)
        List<PolicePersonnel> availablePersonnel = personnelRepository.findByStatus(PersonnelStatus.ACTIVE);
        model.addAttribute("personnelList", availablePersonnel);

        return "admin/duty-form";
    }

    @PostMapping("/admin/duty/save")
    public String saveDuty(@ModelAttribute Duty duty) {
        duty.setStatus("ASSIGNED");
        dutyRepository.save(duty);
        return "redirect:/admin/duty?success=assigned";
    }

    @PostMapping("/admin/duty/complete/{id}")
    public String markCompleteAdmin(@PathVariable("id") Long id) {
        Duty duty = dutyRepository.findById(id).orElseThrow();
        duty.setStatus("COMPLETED");
        dutyRepository.save(duty);
        return "redirect:/admin/duty?success=completed";
    }

    // ================= STAFF PATHS =================

    @GetMapping("/staff/duties")
    public String staffDutyList(Model model, Authentication authentication) {
        model.addAttribute("activeMenu", "duties");
        PolicePersonnel personnel = getLoggedInPersonnel(authentication);
        if (personnel != null) {
            List<Duty> myDuties = dutyRepository.findByPersonnelOrderByDutyDateTimeDesc(personnel);
            model.addAttribute("myDuties", myDuties);

            // For highlighting logic
            boolean hasNewDuty = myDuties.stream().anyMatch(d -> "ASSIGNED".equals(d.getStatus()));
            model.addAttribute("hasNewDuty", hasNewDuty);
        }
        return "staff/duties";
    }

    @PostMapping("/staff/duties/acknowledge/{id}")
    public String acknowledgeDutyStaff(@PathVariable("id") Long id, Authentication authentication) {
        PolicePersonnel personnel = getLoggedInPersonnel(authentication);
        Duty duty = dutyRepository.findById(id).orElseThrow();

        // Optional security check
        if (personnel != null && duty.getPersonnel().getId().equals(personnel.getId())) {
            duty.setStatus("ACKNOWLEDGED"); // Changing ASSIGNED -> ACKNOWLEDGED
            dutyRepository.save(duty);
        }
        return "redirect:/staff/duties?success=acknowledged";
    }
}
