package com.police.station.controller;

import com.police.station.model.LeaveRequest;
import com.police.station.model.LeaveType;
import com.police.station.model.PolicePersonnel;
import com.police.station.model.User;
import com.police.station.repository.LeaveRequestRepository;
import com.police.station.repository.PolicePersonnelRepository;
import com.police.station.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Controller
public class LeaveController {

    @Autowired
    private LeaveRequestRepository leaveRepository;

    @Autowired
    private PolicePersonnelRepository personnelRepository;

    @Autowired
    private UserRepository userRepository;

    private PolicePersonnel getLoggedInPersonnel(Authentication authentication) {
        String username = authentication.getName();
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            Optional<PolicePersonnel> personnelOpt = personnelRepository.findByUser(userOpt.get());
            if (personnelOpt.isPresent()) {
                return personnelOpt.get();
            }
        }
        return null;
    }

    // ================= ADMIN PATHS =================

    @GetMapping("/admin/leave")
    public String adminLeaveList(Model model) {
        model.addAttribute("activeMenu", "leave");
        List<LeaveRequest> leaveRequests = leaveRepository.findAll();
        // sort in descending order in repository could be better but simplified here.
        model.addAttribute("leaveRequests", leaveRequests);
        return "admin/leave";
    }

    @PostMapping("/admin/leave/approve/{id}")
    public String approveLeave(@PathVariable("id") Long id) {
        LeaveRequest leave = leaveRepository.findById(id).orElseThrow();
        leave.setStatus("APPROVED");

        // Deduct from balance
        PolicePersonnel personnel = leave.getPersonnel();
        int days = (int) ChronoUnit.DAYS.between(leave.getFromDate(), leave.getToDate()) + 1;

        if (leave.getLeaveType() == LeaveType.CL)
            personnel.setClBalance(personnel.getClBalance() - days);
        if (leave.getLeaveType() == LeaveType.ML)
            personnel.setMlBalance(personnel.getMlBalance() - days);
        if (leave.getLeaveType() == LeaveType.EL)
            personnel.setElBalance(personnel.getElBalance() - days);

        personnelRepository.save(personnel);
        leaveRepository.save(leave);

        return "redirect:/admin/leave?success=approved";
    }

    @PostMapping("/admin/leave/reject/{id}")
    public String rejectLeave(@PathVariable("id") Long id) {
        LeaveRequest leave = leaveRepository.findById(id).orElseThrow();
        leave.setStatus("REJECTED");
        leaveRepository.save(leave);
        return "redirect:/admin/leave?success=rejected";
    }

    // ================= STAFF PATHS =================

    @GetMapping("/staff/leave")
    public String staffLeaveList(Model model, Authentication authentication) {
        model.addAttribute("activeMenu", "leave");
        PolicePersonnel personnel = getLoggedInPersonnel(authentication);
        if (personnel != null) {
            List<LeaveRequest> myLeaves = leaveRepository.findByPersonnelOrderByFromDateDesc(personnel);
            model.addAttribute("myLeaves", myLeaves);
            model.addAttribute("personnel", personnel);
        }
        return "staff/leave";
    }

    @GetMapping("/staff/leave/new")
    public String showLeaveForm(Model model, Authentication authentication) {
        model.addAttribute("activeMenu", "leave");
        model.addAttribute("leaveRequest", new LeaveRequest());
        model.addAttribute("leaveTypes", java.util.Arrays.asList(LeaveType.values()));

        PolicePersonnel personnel = getLoggedInPersonnel(authentication);
        model.addAttribute("personnel", personnel);

        return "staff/leave-form";
    }

    @PostMapping("/staff/leave/save")
    public String applyLeave(@ModelAttribute LeaveRequest leaveRequest, Authentication authentication) {
        PolicePersonnel personnel = getLoggedInPersonnel(authentication);
        if (personnel != null) {
            leaveRequest.setPersonnel(personnel);
            leaveRequest.setStatus("PENDING");
            leaveRepository.save(leaveRequest);
        }
        return "redirect:/staff/leave?success=applied";
    }
}
