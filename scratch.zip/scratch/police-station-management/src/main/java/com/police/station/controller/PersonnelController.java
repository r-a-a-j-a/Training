package com.police.station.controller;

import com.police.station.model.Designation;
import com.police.station.model.PersonnelStatus;
import com.police.station.model.PolicePersonnel;
import com.police.station.model.User;
import com.police.station.repository.PolicePersonnelRepository;
import com.police.station.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin/personnel")
public class PersonnelController {

    @Autowired
    private PolicePersonnelRepository personnelRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @GetMapping
    public String listPersonnel(Model model) {
        model.addAttribute("activeMenu", "personnel");
        List<PolicePersonnel> personnelList = personnelRepository.findAll();
        model.addAttribute("personnelList", personnelList);
        return "admin/personnel";
    }

    @GetMapping("/new")
    public String showAddForm(Model model) {
        model.addAttribute("activeMenu", "personnel");
        model.addAttribute("personnel", new PolicePersonnel());
        model.addAttribute("designations", Designation.values());
        model.addAttribute("statuses", PersonnelStatus.values());
        return "admin/personnel-form";
    }

    @PostMapping("/save")
    public String savePersonnel(@ModelAttribute PolicePersonnel personnel,
            @RequestParam(required = false) String createLogin,
            @RequestParam(required = false) String defaultPassword) {

        PolicePersonnel savedPersonnel = personnelRepository.save(personnel);

        // If admin opted to create a login account for this personnel
        if ("yes".equals(createLogin) && savedPersonnel.getUser() == null) {
            User newUser = new User();
            newUser.setUsername(savedPersonnel.getPoliceNumber()); // Login ID is police number
            newUser.setPassword(passwordEncoder.encode(defaultPassword));
            newUser.setRole("ROLE_STAFF");
            userRepository.save(newUser);

            savedPersonnel.setUser(newUser);
            personnelRepository.save(savedPersonnel);
        }

        return "redirect:/admin/personnel?success=saved";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        PolicePersonnel personnel = personnelRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid personnel Id:" + id));

        model.addAttribute("activeMenu", "personnel");
        model.addAttribute("personnel", personnel);
        model.addAttribute("designations", Designation.values());
        model.addAttribute("statuses", PersonnelStatus.values());
        return "admin/personnel-form";
    }

    @GetMapping("/delete/{id}")
    public String deletePersonnel(@PathVariable("id") Long id) {
        PolicePersonnel personnel = personnelRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid personnel Id:" + id));
        personnel.setStatus(PersonnelStatus.TRANSFERRED);
        if (personnel.getUser() != null) {
            User userToDelete = personnel.getUser();
            personnel.setUser(null);
            personnelRepository.save(personnel);
            userRepository.delete(userToDelete);
        } else {
            personnelRepository.save(personnel);
        }
        return "redirect:/admin/personnel?success=transferred";
    }
}
