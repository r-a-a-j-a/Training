package com.police.station;

import com.police.station.model.Designation;
import com.police.station.model.PersonnelStatus;
import com.police.station.model.PolicePersonnel;
import com.police.station.model.User;
import com.police.station.repository.PolicePersonnelRepository;
import com.police.station.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class AdminSeeder implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PolicePersonnelRepository personnelRepository;

    @Override
    public void run(String... args) throws Exception {
        if (userRepository.findByUsername("admin").isEmpty()) {
            System.out.println("----- CREATING ADMIN ACCOUNT -----");
            User adminUser = new User();
            adminUser.setUsername("admin");
            adminUser.setPassword(new BCryptPasswordEncoder().encode("admin123"));
            adminUser.setRole("ROLE_ADMIN");

            // Save user first
            userRepository.save(adminUser);

            // Check if profile exists by Police Number or IFHRMS
            java.util.List<PolicePersonnel> existingSuper = personnelRepository.findAll();
            PolicePersonnel adminProfile = null;
            for (PolicePersonnel p : existingSuper) {
                if ("IFHRMS-ADMIN-01".equals(p.getIfhrmsNumber()) || "admin_super".equals(p.getPoliceNumber())) {
                    adminProfile = p;
                    break;
                }
            }

            if (adminProfile == null) {
                adminProfile = new PolicePersonnel();
                adminProfile.setPoliceNumber("admin_super");
                adminProfile.setName("Superintendent of Police");
                adminProfile.setDesignation(Designation.SI);
                adminProfile.setIfhrmsNumber("IFHRMS-ADMIN-01");
                adminProfile.setDateOfEnrolment(LocalDate.of(2000, 1, 1));
                adminProfile.setStatus(PersonnelStatus.ACTIVE);
                adminProfile.setClBalance(15);
                adminProfile.setMlBalance(10);
                adminProfile.setElBalance(30);
            }

            // Link them and save
            adminProfile.setUser(adminUser);
            personnelRepository.save(adminProfile);

            System.out.println("----- ADMIN ACCOUNT CREATED SUCCESSFULLY -----");
        } else {
            System.out.println("----- ADMIN ACCOUNT ALREADY EXISTS -----");
            // Let's force update password just in case
            User adminUser = userRepository.findByUsername("admin").get();
            adminUser.setPassword(new BCryptPasswordEncoder().encode("admin123"));
            userRepository.save(adminUser);
            System.out.println("----- ADMIN PASSWORD RESET TO admin123 -----");
        }
    }
}
