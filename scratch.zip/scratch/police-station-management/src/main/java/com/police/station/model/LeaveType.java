package com.police.station.model;

public enum LeaveType {
    CL, // Casual Leave
    ML, // Medical Leave
    EL // Earned Leave
}
