package com.police.station.controller;

import com.police.station.dto.AttendanceForm;
import com.police.station.model.Attendance;
import com.police.station.model.Designation;
import com.police.station.model.PersonnelStatus;
import com.police.station.model.PolicePersonnel;
import com.police.station.model.User;
import com.police.station.repository.AttendanceRepository;
import com.police.station.repository.PolicePersonnelRepository;
import com.police.station.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;

@Controller
public class AttendanceController {

    @Autowired
    private AttendanceRepository attendanceRepository;

    @Autowired
    private PolicePersonnelRepository personnelRepository;

    @Autowired
    private UserRepository userRepository;

    private PolicePersonnel getLoggedInPersonnel(Authentication authentication) {
        String username = authentication.getName();
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            return personnelRepository.findByUser(userOpt.get()).orElse(null);
        }
        return null;
    }

    // ================= ADMIN: ATTENDANCE REGISTER =================

    @GetMapping("/admin/attendance")
    public String adminAttendance(
            @RequestParam(required = false) Integer year,
            @RequestParam(required = false) Integer month,
            Model model) {

        model.addAttribute("activeMenu", "attendance");

        YearMonth currentYearMonth = (year == null || month == null) ? YearMonth.now() : YearMonth.of(year, month);
        model.addAttribute("currentYearMonth", currentYearMonth);
        model.addAttribute("currentMonthName", currentYearMonth.getMonth().name());
        model.addAttribute("currentYear", currentYearMonth.getYear());

        List<Integer> daysInMonth = new ArrayList<>();
        for (int i = 1; i <= currentYearMonth.lengthOfMonth(); i++) {
            daysInMonth.add(i);
        }
        model.addAttribute("daysInMonth", daysInMonth);

        // Exclude TRANSFERRED, IN_OD, OUT_OD. Include ACTIVE and PENDING
        List<PolicePersonnel> personnelList = personnelRepository.findAll().stream()
                .filter(p -> p.getStatus() == PersonnelStatus.ACTIVE
                        || p.getStatus() == PersonnelStatus.PENDING_APPROVAL)
                .toList();
        model.addAttribute("personnelList", personnelList);

        // Fetch existing attendance for this month
        LocalDate startDate = currentYearMonth.atDay(1);
        LocalDate endDate = currentYearMonth.atEndOfMonth();
        List<Attendance> existingAttendanceList = attendanceRepository.findByAttendanceDateBetween(startDate, endDate);

        // Map: personnelId_date -> status (for rendering grid)
        Map<String, String> attendanceGrid = new HashMap<>();
        for (Attendance att : existingAttendanceList) {
            String key = att.getPersonnel().getId() + "_" + att.getAttendanceDate().getDayOfMonth();
            attendanceGrid.put(key, att.getStatus());
        }
        model.addAttribute("attendanceGrid", attendanceGrid);

        model.addAttribute("attendanceForm", new AttendanceForm());

        return "admin/attendance";
    }

    @PostMapping("/admin/attendance/save")
    public String saveAttendance(
            @RequestParam Integer year,
            @RequestParam Integer month,
            @ModelAttribute AttendanceForm attendanceForm) {

        YearMonth ym = YearMonth.of(year, month);

        if (attendanceForm.getAttendanceMap() != null) {
            for (Map.Entry<String, String> entry : attendanceForm.getAttendanceMap().entrySet()) {
                String key = entry.getKey(); // format: "{id}_{day}"
                String status = entry.getValue();

                if (status != null && !status.trim().isEmpty()) {
                    String[] parts = key.split("_");
                    Long personnelId = Long.parseLong(parts[0]);
                    int day = Integer.parseInt(parts[1]);

                    LocalDate date = ym.atDay(day);

                    PolicePersonnel personnel = personnelRepository.findById(personnelId).orElse(null);
                    if (personnel != null) {
                        Attendance attendance = attendanceRepository.findByPersonnelAndAttendanceDate(personnel, date)
                                .orElse(new Attendance());

                        attendance.setPersonnel(personnel);
                        attendance.setAttendanceDate(date);
                        attendance.setStatus(status);

                        attendanceRepository.save(attendance);
                    }
                }
            }
        }
        return "redirect:/admin/attendance?year=" + year + "&month=" + month + "&success=true";
    }

    // ================= ADMIN: FEEDING GENERATOR =================

    @GetMapping("/admin/feeding")
    public String feedingGenerator(
            @RequestParam(required = false) Integer year,
            @RequestParam(required = false) Integer month,
            Model model) {

        model.addAttribute("activeMenu", "feeding");

        YearMonth currentYearMonth = (year == null || month == null) ? YearMonth.now() : YearMonth.of(year, month);
        model.addAttribute("currentYearMonth", currentYearMonth);

        LocalDate startDate = currentYearMonth.atDay(1);
        LocalDate endDate = currentYearMonth.atEndOfMonth();

        List<PolicePersonnel> allPersonnel = personnelRepository.findAll();
        List<Map<String, Object>> feedingReport = new ArrayList<>();

        int normalRate = 300;
        int etrRate = 500;

        double totalNormalAmount = 0;
        double totalEtrAmount = 0;

        for (PolicePersonnel p : allPersonnel) {
            // Only specific designations are eligible
            if (p.getDesignation() == Designation.PC ||
                    p.getDesignation() == Designation.GR_I_PC ||
                    p.getDesignation() == Designation.HC ||
                    p.getDesignation() == Designation.SSI ||
                    p.getDesignation() == Designation.SI) {

                List<Attendance> monthlyAtt = attendanceRepository.findByPersonnelOrderByAttendanceDateDesc(p).stream()
                        .filter(a -> !a.getAttendanceDate().isBefore(startDate)
                                && !a.getAttendanceDate().isAfter(endDate))
                        .filter(a -> "P".equals(a.getStatus())) // Only count Present days
                        .toList();

                int normalDays = 0;
                int etrDays = 0; // Sundays

                for (Attendance a : monthlyAtt) {
                    if (a.getAttendanceDate().getDayOfWeek() == DayOfWeek.SUNDAY) {
                        etrDays++;
                    } else {
                        normalDays++;
                    }
                }

                if (normalDays > 0 || etrDays > 0) {
                    Map<String, Object> map = new HashMap<>();
                    map.put("personnel", p);
                    map.put("normalDays", normalDays);
                    map.put("etrDays", etrDays);
                    map.put("normalAmount", normalDays * normalRate);
                    map.put("etrAmount", etrDays * etrRate);
                    map.put("totalAmount", (normalDays * normalRate) + (etrDays * etrRate));

                    totalNormalAmount += (normalDays * normalRate);
                    totalEtrAmount += (etrDays * etrRate);

                    feedingReport.add(map);
                }
            }
        }

        model.addAttribute("feedingReport", feedingReport);
        model.addAttribute("totalNormalAmount", totalNormalAmount);
        model.addAttribute("totalEtrAmount", totalEtrAmount);
        model.addAttribute("grandTotal", totalNormalAmount + totalEtrAmount);

        return "admin/feeding";
    }

    // ================= STAFF: VIEW MY ATTENDANCE =================

    @GetMapping("/staff/attendance")
    public String staffAttendance(Model model, Authentication authentication) {
        model.addAttribute("activeMenu", "attendance");
        PolicePersonnel personnel = getLoggedInPersonnel(authentication);
        if (personnel != null) {
            List<Attendance> myAttendance = attendanceRepository.findByPersonnelOrderByAttendanceDateDesc(personnel);
            model.addAttribute("myAttendance", myAttendance);

            // Current month summary stats
            YearMonth now = YearMonth.now();
            long presentCount = myAttendance.stream()
                    .filter(a -> YearMonth.from(a.getAttendanceDate()).equals(now) && "P".equals(a.getStatus()))
                    .count();
            long absentCount = myAttendance.stream()
                    .filter(a -> YearMonth.from(a.getAttendanceDate()).equals(now) && "A".equals(a.getStatus()))
                    .count();

            model.addAttribute("presentCount", presentCount);
            model.addAttribute("absentCount", absentCount);
        }
        return "staff/attendance";
    }
}
