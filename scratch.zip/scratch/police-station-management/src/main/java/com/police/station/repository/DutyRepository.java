package com.police.station.repository;

import com.police.station.model.Duty;
import com.police.station.model.PolicePersonnel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DutyRepository extends JpaRepository<Duty, Long> {
    List<Duty> findByPersonnelOrderByDutyDateTimeDesc(PolicePersonnel personnel);
}
