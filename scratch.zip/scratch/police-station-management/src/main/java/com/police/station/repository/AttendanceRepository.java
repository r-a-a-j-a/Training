package com.police.station.repository;

import com.police.station.model.Attendance;
import com.police.station.model.PolicePersonnel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
    List<Attendance> findByPersonnelOrderByAttendanceDateDesc(PolicePersonnel personnel);

    // For the grid view
    List<Attendance> findByAttendanceDateBetween(LocalDate startDate, LocalDate endDate);

    // To check if attendance already mapped for a specific date
    Optional<Attendance> findByPersonnelAndAttendanceDate(PolicePersonnel personnel, LocalDate date);
}
