package com.police.station.controller;

import com.police.station.model.PersonnelStatus;
import com.police.station.model.PolicePersonnel;
import com.police.station.repository.PolicePersonnelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private PolicePersonnelRepository personnelRepository;

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("activeMenu", "dashboard");

        List<PolicePersonnel> activePersonnel = personnelRepository.findByStatus(PersonnelStatus.ACTIVE);
        List<PolicePersonnel> inOdPersonnel = personnelRepository.findByStatus(PersonnelStatus.IN_OD);
        List<PolicePersonnel> outOdPersonnel = personnelRepository.findByStatus(PersonnelStatus.OUT_OD);

        model.addAttribute("totalStrength", activePersonnel.size() + inOdPersonnel.size());
        model.addAttribute("activeCount", activePersonnel.size());
        model.addAttribute("inOdCount", inOdPersonnel.size());
        model.addAttribute("outOdCount", outOdPersonnel.size());

        return "admin/dashboard";
    }
}
