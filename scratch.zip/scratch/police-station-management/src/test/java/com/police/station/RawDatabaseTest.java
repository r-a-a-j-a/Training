package com.police.station;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

@SpringBootTest
public class RawDatabaseTest {

    @Autowired
    private DataSource dataSource;

    @Test
    public void printUsersTable() throws Exception {
        System.out
                .println("==========================================================================================");
        System.out.println("----- RAW JDBC DATABASE USERS TABLE DUMP -----");
        try (Connection conn = dataSource.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM users")) {

            int columnCount = rs.getMetaData().getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                System.out.print(rs.getMetaData().getColumnName(i) + "\t|\t");
            }
            System.out.println();

            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    System.out.print(rs.getString(i) + "\t|\t");
                }
                System.out.println();
            }
        }
        System.out
                .println("==========================================================================================");
    }
}
