package com.police.station;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@SpringBootTest
public class FixDbTest {

    @Autowired
    private DataSource dataSource;

    @Test
    public void fixAdmin() throws Exception {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String hash = encoder.encode("admin123");

        try (Connection conn = dataSource.getConnection()) {

            // 1. Delete broken admin in users if exists (with null username)
            try (PreparedStatement stmt = conn
                    .prepareStatement("DELETE FROM users WHERE username IS NULL OR username = 'admin'")) {
                int deleted = stmt.executeUpdate();
                System.out.println("Deleted " + deleted + " broken admin users.");
            }

            // 2. Insert fresh admin user
            long newUserId = -1;
            try (PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO users (username, password, role) VALUES ('admin', ?, 'ROLE_ADMIN')",
                    PreparedStatement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, hash);
                stmt.executeUpdate();
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        newUserId = rs.getLong(1);
                    }
                }
            }
            System.out.println("Inserted fresh admin user with ID: " + newUserId);

            // 3. Delete existing broken admin profile if exists
            try (PreparedStatement stmt = conn.prepareStatement(
                    "DELETE FROM police_personnel WHERE police_number = 'admin_super' OR ifhrms_number = 'IFHRMS-ADMIN'")) {
                stmt.executeUpdate();
            }

            // 4. Insert fresh admin profile
            try (PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO police_personnel (police_number, name, designation, status, user_id, cl_balance, ml_balance, el_balance, ifhrms_number, date_of_enrolment) VALUES ('admin_super', 'Superintendent of Police', 'SI', 'ACTIVE', ?, 15, 10, 30, 'IFHRMS-ADMIN', '2000-01-01')")) {
                stmt.setLong(1, newUserId);
                stmt.executeUpdate();
            }
            System.out.println("Inserted fresh Admin Personnel Profile.");
        }
    }
}
