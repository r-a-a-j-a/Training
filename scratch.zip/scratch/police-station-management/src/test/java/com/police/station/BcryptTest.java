package com.police.station;

import org.junit.jupiter.api.Test;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class BcryptTest {

    @Test
    public void testHash() {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String newHash = encoder.encode("admin123");
        System.out.println("----- BCRYPT TEST RESULTS -----");
        System.out.println("New Hash for 'admin123': " + newHash);
        System.out.println("-------------------------------");
    }
}
