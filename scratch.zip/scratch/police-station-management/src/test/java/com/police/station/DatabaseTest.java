package com.police.station;

import com.police.station.model.User;
import com.police.station.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.List;

@SpringBootTest
public class DatabaseTest {

    @Autowired
    private UserRepository userRepository;

    @Test
    public void testUsers() {
        System.out
                .println("==========================================================================================");
        System.out.println("----- DIAGNOSTIC: DATABASE USERS -----");
        List<User> users = userRepository.findAll();
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        for (User user : users) {
            System.out.println("User ID: " + user.getId());
            System.out.println("Username: " + user.getUsername());
            System.out.println("Role: " + user.getRole());
            System.out.println("Stored Hash: " + user.getPassword());
            System.out.println("Does password match 'admin123': " + encoder.matches("admin123", user.getPassword()));
            System.out.println("Does password match 'password': " + encoder.matches("password", user.getPassword()));
            System.out.println("Does password match 'admin': " + encoder.matches("admin", user.getPassword()));
            System.out.println("--------------------------");
        }
        System.out
                .println("==========================================================================================");
    }
}
