import { Component } from '@angular/core';

@Component({
  selector: 'app-calc',
  templateUrl: './calc.html',
  styleUrls: ['./calc.css']
})
export class CalcComponent {

  display: string = '';

  append(value: string): void {
    this.display += value;
  }

  clear(): void {
    this.display = '';
  }

  calculate(): void {
    try {
      this.display = eval(this.display);
    } catch {
      this.display = 'Error';
    }
  }
}
