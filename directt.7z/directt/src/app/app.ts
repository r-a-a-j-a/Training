import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Demos } from "./demos/demos";
import { Loginout } from "./loginout/loginout";
import { DepInjection } from "./dep-injection/dep-injection";

@Component({
  selector: 'app-root',
  imports: [ DepInjection],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('directt');
  
}
