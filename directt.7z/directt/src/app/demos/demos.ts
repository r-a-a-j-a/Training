import { Component } from '@angular/core';

@Component({
  selector: 'app-demos',
  imports: [],
  templateUrl: './demos.html',
  styleUrl: './demos.css',
})
export class Demos {
  name:string="raja";
  course:string="angular";
  fees:number=999;

}
