import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DepInjection } from './dep-injection';

describe('DepInjection', () => {
  let component: DepInjection;
  let fixture: ComponentFixture<DepInjection>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DepInjection]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DepInjection);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
