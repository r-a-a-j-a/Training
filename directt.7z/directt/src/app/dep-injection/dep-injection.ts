import { Component } from '@angular/core';
import { Serviceac } from '../serviceac';

@Component({
  selector: 'app-dep-injection',
  imports: [],
  templateUrl: './dep-injection.html',
  styleUrl: './dep-injection.css',
})
export class DepInjection {
  message=''
  constructor  ( private serviceac: Serviceac){

  
  }
acOn(){

  this.message=this.serviceac.turnOn();
}
acOff(){

  this.message=this.serviceac.turnOff();
}
}
