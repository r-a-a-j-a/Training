import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Serviceac {
turnOn(){
  return "Ac is ON"
}
turnOff(){
  return"Ac is OFF"
}  
}
