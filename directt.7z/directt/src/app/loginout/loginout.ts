import { CommonModule, NgIf } from '@angular/common';
import { Component } from '@angular/core';
//import { CommonModule, NgIf } from "../../../node_modules/@angular/common/types/_common_module-chunk";

@Component({
  selector: 'app-loginout',
  imports: [CommonModule],
  templateUrl: './loginout.html',
  styleUrl: './loginout.css',
})
export class Loginout {

//-- ngif
isLoggedIn:boolean=false;
login()
{
  this.isLoggedIn=true;
}
logout()
{
  this.isLoggedIn=false;
}
//--ngfor

courses:string[]=['Angular','react','Javascrpt','node']

//--ngSwitch
 role: string = '';  
 setRole(newRole: string) {
    this.role = newRole;
}
}
