import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Loginout } from './loginout';

describe('Loginout', () => {
  let component: Loginout;
  let fixture: ComponentFixture<Loginout>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Loginout]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Loginout);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
