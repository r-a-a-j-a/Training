import { TestBed } from '@angular/core/testing';

import { Serviceac } from './serviceac';

describe('Serviceac', () => {
  let service: Serviceac;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Serviceac);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
