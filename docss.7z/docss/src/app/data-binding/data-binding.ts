import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-data-binding',
  imports: [FormsModule],
  templateUrl: './data-binding.html',
  styleUrl: './data-binding.css',
})
export class DataBinding {
  //Interpolation
  name="tamilnadu";

  //Property binding
  isDisabled=false;

  //Event Binding
  enableButton(){
    this.isDisabled=true;
  }

  //Two way binding
  username='';
  showAlert(){
    alert('helo' +this.username)
  }

}
