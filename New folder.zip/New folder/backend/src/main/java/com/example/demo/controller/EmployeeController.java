package com.example.demo.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;

@RestController
@CrossOrigin(origins="http://localhost:4200") //Allowing Angular
public class EmployeeController {
	@GetMapping("/employees")
	public List<Employee> getEmployees()
	{
		return Arrays.asList(
				new Employee(1,"Raja"),
				new Employee(2,"Siva"),
				new Employee(3, "Pradeep")
				);
				
	}
 
}
