package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Feb23Application {

	public static void main(String[] args) {
		SpringApplication.run(Feb23Application.class, args);
	}

}
