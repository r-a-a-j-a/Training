package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @GetMapping("/")
    public String index() {
        return "Welcome! Try /home to login.";
    }

    @GetMapping("/home")
    public String home() {
        return "Login Successful ✅";
    }
}