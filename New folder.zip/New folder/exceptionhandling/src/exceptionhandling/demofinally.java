package exceptionhandling;

public class demofinally {
	public static void main(String[] args) {
		try {
			int a[]= {10,20,30};
			System.out.println(a[0]);
			System.out.println(a[1]);
			System.out.println(a[2]);
			System.out.println(10/2);
			System.out.println(10/0);
		}catch (Exception e) {
			System.out.println("exxception caught "+ e  );
		}
		finally {
			System.out.println("Im finally");
		}
		
	}

}