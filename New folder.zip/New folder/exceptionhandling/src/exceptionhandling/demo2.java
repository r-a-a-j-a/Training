package exceptionhandling;

public class demo2 {
	public static void main(String[] args) {
		try {
			int a[]= {10,20,30};
			System.out.println(a[0]);
			System.out.println(a[1]);
			System.out.println(a[2]);
			System.out.println(10/0);
		} catch (ArithmeticException e) {
			System.out.println("exxception caught "+ e  );
			
		}
			catch (ArrayIndexOutOfBoundsException e) {
				System.out.println("exxception caught "+ e  );
			}
	}

}