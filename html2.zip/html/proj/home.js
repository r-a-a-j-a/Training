// Nature-themed homepage — protected and interactive (client-side demo)
document.addEventListener('DOMContentLoaded', () => {
  // Auth guard (reuse login storage keys)
  const sessionLogged = sessionStorage.getItem('loggedIn') === 'true';
  const localLogged = localStorage.getItem('loggedIn') === 'true';
  if (!sessionLogged && !localLogged) {
    window.location.href = 'index.html';
    return;
  }

  // Elements
  const logoutBtn = document.getElementById('logout');
  const emailSpan = document.getElementById('user-email');
  const profileEmail = document.getElementById('profile-email');
  const avatar = document.getElementById('avatar');
  const yearSpan = document.getElementById('year');
  const trailsList = document.getElementById('trails-list');
  const trailFilter = document.getElementById('trail-filter');
  const plantList = document.getElementById('plant-list');
  const sightingsList = document.getElementById('sightings-list');
  const gallery = document.getElementById('gallery');
  const refreshWeatherBtn = document.getElementById('refresh-weather');

  const storedEmail = sessionStorage.getItem('userEmail') || localStorage.getItem('userEmail') || 'Nature Lover';
  emailSpan.textContent = storedEmail;
  profileEmail.textContent = storedEmail;
  avatar.textContent = (storedEmail[0] || 'N').toUpperCase();
  if (yearSpan) yearSpan.textContent = new Date().getFullYear();

  logoutBtn.addEventListener('click', () => {
    sessionStorage.removeItem('loggedIn'); sessionStorage.removeItem('userEmail');
    localStorage.removeItem('loggedIn'); localStorage.removeItem('userEmail');
    setTimeout(() => window.location.href = 'index.html', 120);
  });

  // Mock trail data
  const trails = [
    {name: 'Riverside Loop', distance: '4.2 km', difficulty: 'Easy', time: '30–45m'},
    {name: 'Pine Ridge Trail', distance: '9.1 km', difficulty: 'Moderate', time: '2–3h'},
    {name: 'Sunset Overlook', distance: '3.5 km', difficulty: 'Easy', time: '25–40m'},
    {name: 'Cedar Summit', distance: '12.4 km', difficulty: 'Hard', time: '4–6h'}
  ];

  // Plants (persist lastWatered in localStorage)
  const plantsKey = 'nh_plants';
  const defaultPlants = [
    {id: 'p1', name: 'Monstera', species: 'Monstera deliciosa'},
    {id: 'p2', name: 'Aloe Vera', species: 'Aloe barbadensis'},
    {id: 'p3', name: 'Peace Lily', species: 'Spathiphyllum'}
  ];
  const loadPlants = () => {
    try {
      const raw = localStorage.getItem(plantsKey);
      return raw ? JSON.parse(raw) : defaultPlants.map(p => ({...p, lastWatered: null}));
    } catch { return defaultPlants.map(p => ({...p, lastWatered: null})); }
  };
  let plants = loadPlants();

  // Sightings & gallery (simple in-memory arrays, gallery persisted to localStorage)
  const sightingsKey = 'nh_sightings';
  const galleryKey = 'nh_gallery';
  const loadSightings = () => {
    try { return JSON.parse(localStorage.getItem(sightingsKey) || '[]'); } catch { return []; }
  };
  const loadGallery = () => {
    try { return JSON.parse(localStorage.getItem(galleryKey) || '[]'); } catch { return []; }
  };
  let sightings = loadSightings();
  let photos = loadGallery();

  // Render helpers
  function renderTrails(filter = '') {
    trailsList.innerHTML = '';
    const q = filter.trim().toLowerCase();
    trails.filter(t => !q || t.name.toLowerCase().includes(q)).forEach(t => {
      const li = document.createElement('li'); li.className = 'trail-item';
      li.innerHTML = `<div>
                        <div style="font-weight:700">${t.name}</div>
                        <div class="trail-meta"><small>${t.distance} • ${t.difficulty} • ${t.time}</small></div>
                      </div>
                      <div><button class="btn subtle" data-name="${t.name}">Start</button></div>`;
      trailsList.appendChild(li);
    });
  }

  function renderPlants() {
    plantList.innerHTML = '';
    plants.forEach(p => {
      const li = document.createElement('li'); li.className = 'plant-item';
      const lw = p.lastWatered ? new Date(p.lastWatered).toLocaleString() : 'never';
      li.innerHTML = `<div>
                        <div style="font-weight:700">${p.name}</div>
                        <div class="muted small">${p.species} • last watered: ${lw}</div>
                      </div>
                      <div class="plant-actions">
                        <button class="btn outline" data-id="${p.id}" data-action="water">💧 Water</button>
                        <button class="btn subtle" data-id="${p.id}" data-action="edit">✎</button>
                      </div>`;
      plantList.appendChild(li);
    });
  }

  function renderSightings() {
    sightingsList.innerHTML = '';
    (sightings.slice().reverse()).forEach(s => {
      const li = document.createElement('li'); li.className = 'sighting-item';
      li.innerHTML = `<div style="font-weight:700">${s.species}</div><div class="muted small">${s.location} • ${new Date(s.when).toLocaleString()}</div>`;
      sightingsList.appendChild(li);
    });
  }

  function renderGallery() {
    gallery.innerHTML = '';
    if (photos.length === 0) {
      gallery.innerHTML = `<div class="muted">No photos yet — add a snapshot from a trail or backyard.</div>`;
      return;
    }
    photos.slice().reverse().forEach((p, i) => {
      const d = document.createElement('div');
      d.className = 'photo';
      d.style.backgroundImage = `url(${p.data})`;
      d.title = p.caption || 'Nature photo';
      d.addEventListener('click', () => window.open(p.data, '_blank'));
      gallery.appendChild(d);
    });
  }

  // Initial render
  renderTrails();
  renderPlants();
  renderSightings();
  renderGallery();

  // Interactions
  trailFilter && trailFilter.addEventListener('input', (e) => renderTrails(e.target.value));
  document.getElementById('explore-trails').addEventListener('click', () => alert('Opening trail finder — demo'));
  document.getElementById('log-sighting').addEventListener('click', () => addSightingPrompt());
  document.getElementById('add-plant').addEventListener('click', () => {
    const name = prompt('Plant name:');
    if (!name) return;
    const species = prompt('Species (optional):') || 'Unknown';
    const id = 'p' + Date.now();
    plants.unshift({id, name, species, lastWatered: null});
    localStorage.setItem(plantsKey, JSON.stringify(plants));
    renderPlants();
  });

  // plant water / edit buttons (event delegation)
  plantList.addEventListener('click', (ev) => {
    const btn = ev.target.closest('button');
    if (!btn) return;
    const id = btn.dataset.id;
    const action = btn.dataset.action;
    if (action === 'water') {
      const p = plants.find(x => x.id === id);
      if (!p) return;
      p.lastWatered = new Date().toISOString();
      localStorage.setItem(plantsKey, JSON.stringify(plants));
      renderPlants();
      alert(`${p.name} marked as watered.`);
    } else if (action === 'edit') {
      const p = plants.find(x => x.id === id);
      if (!p) return;
      const newName = prompt('Rename plant:', p.name);
      if (newName) { p.name = newName; localStorage.setItem(plantsKey, JSON.stringify(plants)); renderPlants(); }
    }
  });

  // Add photo (uses File picker and stores base64 in localStorage)
  document.getElementById('add-photo').addEventListener('click', async () => {
    const fileInput = document.createElement('input');
    fileInput.type = 'file'; fileInput.accept = 'image/*';
    fileInput.onchange = () => {
      const f = fileInput.files[0];
      if (!f) return;
      const reader = new FileReader();
      reader.onload = (e) => {
        const data = e.target.result;
        const caption = prompt('Caption (optional):') || '';
        photos.push({data, caption, when: new Date().toISOString()});
        localStorage.setItem(galleryKey, JSON.stringify(photos));
        renderGallery();
        alert('Photo added to gallery (stored in your browser).');
      };
      reader.readAsDataURL(f);
    };
    fileInput.click();
  });

  // Add sighting prompt
  function addSightingPrompt() {
    const species = prompt('Species observed: (e.g., "Red Fox")');
    if (!species) return;
    const location = prompt('Location (optional):') || 'Unknown place';
    const s = {species, location, when: new Date().toISOString()};
    sightings.push(s);
    localStorage.setItem(sightingsKey, JSON.stringify(sightings));
    renderSightings();
    alert('Sighting logged. Thank you for recording!');
  }

  // Weather (mocked quick refresh)
  const tempEl = document.getElementById('temp');
  const condEl = document.getElementById('condition');
  const airEl = document.getElementById('air');
  const humidityEl = document.getElementById('humidity');

  function randomWeather() {
    const temps = [12, 14, 16, 18, 20, 22, 24];
    const cond = ['Sunny','Partly cloudy','Overcast','Light rain','Breezy'];
    const idx = Math.floor(Math.random()*temps.length);
    tempEl.textContent = temps[idx] + '°C';
    condEl.textContent = cond[Math.floor(Math.random()*cond.length)];
    airEl.textContent = ['Good','Fair','Moderate'][Math.floor(Math.random()*3)];
    humidityEl.textContent = Math.round(40 + Math.random()*50) + '%';
  }
  randomWeather();
  refreshWeatherBtn && refreshWeatherBtn.addEventListener('click', randomWeather);

  // Simple search (enter in global search filters trails)
  const globalSearch = document.getElementById('global-search');
  globalSearch.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const q = globalSearch.value.trim();
      if (q) {
        trailFilter.value = q;
        renderTrails(q);
      }
    }
  });

  // Accessibility: forward slash to focus search
  window.addEventListener('keydown', (e) => {
    if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
      e.preventDefault();
      globalSearch.focus();
    }
  });
});