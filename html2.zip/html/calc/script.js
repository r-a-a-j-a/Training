// Simple calculator logic
const screen = document.getElementById('screen');
const buttons = document.querySelectorAll('.btn');

let expression = ''; // raw expression using calculator symbols (×, ÷)
const operators = ['+', '-', '×', '÷'];

function updateScreen(value){
  screen.textContent = value || '0';
}

function appendValue(val){
  // Prevent multiple leading zeros
  if (expression === '0' && val === '0') return;

  // If last char is operator and val is operator, replace operator
  const last = expression.slice(-1);

  if (operators.includes(val)) {
    if (expression === '' && val !== '-') return; // don't start with +,×,÷
    if (operators.includes(last)) {
      // replace last operator with new one
      expression = expression.slice(0, -1) + val;
      updateScreen(expression);
      return;
    }
  }

  // Prevent multiple decimals in the same number
  if (val === '.') {
    // find last operator position
    const parts = expression.split(/[\+\-\×\÷]/);
    const lastPart = parts[parts.length - 1];
    if (lastPart.includes('.')) return;
    if (lastPart === '') {
      // If starting a number with '.', prefix with '0'
      val = '0.';
    }
  }

  expression += val;
  updateScreen(expression);
}

function clearAll(){
  expression = '';
  updateScreen('0');
}

function backspace(){
  expression = expression.slice(0, -1);
  updateScreen(expression || '0');
}

function percent(){
  // Convert current expression to number if possible and apply percent to last number
  // Approach: evaluate current expression, then divide by 100
  try{
    const result = evaluateExpression(expression);
    expression = String(result / 100);
    updateScreen(expression);
  } catch {
    updateScreen('Error');
    expression = '';
  }
}

function sanitizeForEval(expr){
  // Replace calculator symbols
  let e = expr.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-');
  // Only allow digits, operators, parentheses, decimal point, and spaces
  if (!/^[0-9+\-*/().\s]*$/.test(e)) throw new Error('Invalid characters');
  return e;
}

function evaluateExpression(expr){
  if (!expr) return 0;
  const sanitized = sanitizeForEval(expr);
  // Avoid using eval directly; use Function to evaluate expression
  // This is still JS code execution, but sanitized input drastically reduces risk.
  // For full safety, implement a proper expression parser.
  // Also prevent trailing operator
  const trimmed = sanitized.replace(/[\+\-*/. ]+$/,'');
  if (trimmed === '') throw new Error('Nothing to evaluate');
  // Evaluate
  // eslint-disable-next-line no-new-func
  const fn = new Function('return (' + trimmed + ')');
  const result = fn();
  if (!isFinite(result)) throw new Error('Result not finite');
  // Round small floating point errors
  return Math.round(result * 1e12) / 1e12;
}

function calculate(){
  try{
    const result = evaluateExpression(expression);
    expression = String(result);
    updateScreen(expression);
  } catch (err){
    updateScreen('Error');
    expression = '';
    console.error(err);
  }
}

// Button click handling
buttons.forEach(btn => {
  btn.addEventListener('click', () => {
    const val = btn.dataset.value;
    const action = btn.dataset.action;

    if (action === 'clear') {
      clearAll();
      return;
    }
    if (action === 'back') {
      backspace();
      return;
    }
    if (action === 'equals') {
      calculate();
      return;
    }
    if (action === 'percent') {
      percent();
      return;
    }
    if (val) {
      appendValue(val);
    }
  });
});

// Keyboard support
window.addEventListener('keydown', (e) => {
  if (e.key >= '0' && e.key <= '9') {
    appendValue(e.key);
    return;
  }
  if (e.key === '.' || e.key === ',') {
    appendValue('.');
    return;
  }
  if (e.key === 'Enter' || e.key === '=') {
    e.preventDefault();
    calculate();
    return;
  }
  if (e.key === 'Backspace') {
    backspace();
    return;
  }
  if (e.key === 'Escape') {
    clearAll();
    return;
  }
  // Operators
  if (e.key === '+' || e.key === '-' || e.key === '*' || e.key === '/') {
    const mapping = {'*':'×','/':'÷'};
    appendValue(mapping[e.key] || e.key);
    return;
  }
});

// Initialize
clearAll();