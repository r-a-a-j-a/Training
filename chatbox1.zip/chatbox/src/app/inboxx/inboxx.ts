import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-group-chat',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './inboxx.html',
  styleUrls: ['./inboxx.css']
})
export class GroupChatComponent {

  person1Message: string = '';
  person2Message: string = '';
  person3Message: string = '';

  chatMessages: any[] = [];

  sendMessage(person: string, message: string) {
    
    if (message.trim()) {
      this.chatMessages.push({
        sender: person,
        text: message
      });
    }

    // Clear input after sending
    if (person == 'Person 1') this.person1Message = '';
    if (person == 'Person 2') this.person2Message = '';
    if (person == 'Person 3') this.person3Message = '';
  }
}
