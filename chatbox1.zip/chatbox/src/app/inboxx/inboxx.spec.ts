import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Inboxx } from './inboxx';

describe('Inboxx', () => {
  let component: Inboxx;
  let fixture: ComponentFixture<Inboxx>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Inboxx]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Inboxx);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
