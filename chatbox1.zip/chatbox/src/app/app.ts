import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { GroupChatComponent } from "./inboxx/inboxx";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, GroupChatComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('chatbox');
}
