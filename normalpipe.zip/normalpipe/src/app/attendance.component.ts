import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Student {
  id: number;
  name: string;
}

interface AttendanceRecord {
  date: string;
  records: { [studentId: number]: boolean };
}

@Component({
  selector: 'app-attendance',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.css']
})
export class AttendanceComponent {
  students: Student[] = [];
  attendance: AttendanceRecord[] = [];
  newStudentName = '';
  today = new Date().toISOString().split('T')[0];

  addStudent() {
    if (this.newStudentName.trim()) {
      const newId = this.students.length > 0 ? Math.max(...this.students.map(s => s.id)) + 1 : 1;
      this.students.push({ id: newId, name: this.newStudentName.trim() });
      this.newStudentName = '';
    }
  }

  removeStudent(id: number) {
    this.students = this.students.filter(s => s.id !== id);
    this.attendance.forEach(record => {
      delete record.records[id];
    });
  }

  markAttendance(studentId: number, present: boolean) {
    let record = this.attendance.find(r => r.date === this.today);
    if (!record) {
      record = { date: this.today, records: {} };
      this.attendance.push(record);
    }
    record.records[studentId] = present;
  }

  getAttendance(studentId: number, date: string): string {
    const record = this.attendance.find(r => r.date === date);
    if (!record || record.records[studentId] === undefined) return '-';
    return record.records[studentId] ? 'Present' : 'Absent';
  }

  getDates(): string[] {
    return this.attendance.map(r => r.date);
  }
}
