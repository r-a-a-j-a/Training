import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

@Component({
  selector: 'app-inbuilt',
  imports: [CommonModule],
  templateUrl: './inbuilt.html',
  styleUrl: './inbuilt.css',
})
export class Inbuilt {

  // 1️⃣ String value
  str: string = 'Hello Everyone';

  // 2️⃣ Number value (used for currency pipe)
  amount: number = 5000;

  // 3️⃣ Date value (used for date pipe)
  today: Date = new Date();

  // 4️⃣ Object value (used for json pipe)
  emp = {
    id: 101,
    name: 'Anand',
    role: 'Angular Developer',
    salary: 60000
  };
}
