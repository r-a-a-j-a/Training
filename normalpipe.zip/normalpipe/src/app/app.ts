
import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Inbuilt } from "./inbuilt/inbuilt";
import { AttendanceComponent } from './attendance.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class App {
  protected readonly title = signal('normalpipe');
}
