package demo;

abstract class Abc
{
    abstract  void m1();
}


public class abstractt extends Abc {
	
	 void m1()
		{
			System.out.println("method m1");
		}
public static void main(String[] args) {
	abstractt  xy = new abstractt();
   xy.m1();

	
}
}
	