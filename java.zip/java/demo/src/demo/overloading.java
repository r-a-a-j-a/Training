package demo;

public class overloading {

		void m1()
		{
			System.out.println("method m1");
		}
		void m1(int a)
		{
			System.out.println("method m1");
		}
	public static void main(String[] args) {
		overloading  xy = new overloading();
	   xy.m1();
		xy.m1(10);
	}
	}

	
		


