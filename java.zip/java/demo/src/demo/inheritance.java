package demo;




class GrandFather 
{
	void sugar()
	{
		System.out.println("i am having sugar");
	}
}

class father extends GrandFather{
	void bp()
	{

		System.out.println("I am having BP");
	}
}

public class inheritance extends father {
	

	
public static void main(String[] args) {
	inheritance  cc = new inheritance();
	cc.bp();
	cc.sugar();
}
}