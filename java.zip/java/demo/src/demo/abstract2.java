package demo;

abstract class Atm {
	abstract void withdraw();

	abstract void deposite();
}

abstract class Abcde extends Atm {

	
	void withdraw() {
		System.out.println("asdfasdf");
	}

}

public class abstract2 extends Abcde {
	
	void deposite() {

		System.out.println("ahello wrld");
	}

	public static void main(String[] args) {
		abstract2 xy = new abstract2();
		xy.withdraw();
		xy.deposite();
	}

}