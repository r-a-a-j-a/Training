package demo;



class Abcd
{
void m1()
{
	System.out.println("method m1 fsdasdfsdfaro paarent clas");
}
}

public class overriding extends Abcd {

public static void main(String[] args) {
overriding  xy = new overriding();
xy.m1();


}
}
