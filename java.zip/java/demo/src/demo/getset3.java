package demo;


class Abcs
{
private	int a;
	
public int getA() {
	return a;
}

public void setA(int a) {
	this.a = a;
}

	
}
public class getset3 extends Abcs {

public static void main(String[] args) {
	getset3  xy = new getset3();
    xy.setA(22);
    System.out.println(xy.getA());
	
}
}