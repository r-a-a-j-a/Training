package demo;


abstract class ATM {
	abstract void withdraw();

	abstract void deposite();

}

public class abstract1 extends ATM{

	void withdraw() {
		System.out.println("misnisnfoasndfoasodfnasodf");
	}

	void deposite() {
		System.out.println("sdfoasdfoasjfoasjdfoasodfaosjfoas");
	}

	public static void main(String[] args) {
		abstract1 xy = new abstract1();
xy.withdraw();
xy.deposite();
	}
}
