package exceptionhandling;

public class demo5 {
	public static void main(String[] args) {
		try {
			
			System.out.println(10/0);
		} catch (Exception e) {
			System.out.println("exxception caught "+ e  );
		}try {
			int a[]= {10,20,30};
			System.out.println(a[0]);
			System.out.println(a[1]);
			System.out.println(a[2]);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("exxception caught "+ e  );
		}
			
		System.out.println("kjfdhlhlfgdhogih"  );
	}

}