package exceptionhandling;

public class demo1 {
	public static void main(String[] args) {
		try {
			System.out.println("hafjkhgjkdhgjkhg");
			System.out.println("hafjkhgjkdhgjkhg");
			System.out.println("hafjkhgjkdhgjkhg");
			System.out.println(10/0);
			System.out.println("hafjkhgjkdhgjkhg");
		} catch ( Exception e) {
		System.out.println("exception caught  "+ e);
		}
	}

}
