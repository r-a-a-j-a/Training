function validateForm() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    if (username == "") {
        alert("user cannot be empty");
        return false;
    }
    if (username !== "" && password !== "") {
        alert("welcome to the webpage");
        window.location.href = "file:///C:/Users/RCC/Desktop/html/webpage/index.html";
        return false;

    }
    if (password == "") {
        alert("password cannot be empty");
        return false;
    } //else {
    //   alert("your password is incorrect")

    // }
}