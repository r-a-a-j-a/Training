// Simple client-side login demo + redirect to homepage
// NOTE: This is for demonstration only. Never keep real credentials in client-side code.
// Replace with server-side authentication for production.

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('login-form');
  const email = document.getElementById('email');
  const password = document.getElementById('password');
  const message = document.getElementById('message');
  const toggle = document.getElementById('toggle-password');
  const rememberCheckbox = document.getElementById('remember');

  // Demo credentials (client-side only)
  const DEMO_EMAIL = 'demo@example.com';
  const DEMO_PASS = 'DemoPass123';

  // If already logged in (session or persistent), redirect to homepage
  const alreadyLogged =
    sessionStorage.getItem('loggedIn') === 'true' ||
    localStorage.getItem('loggedIn') === 'true';
  if (alreadyLogged) {
    window.location.href = 'home.html';
    return;
  }

  toggle.addEventListener('click', () => {
    const isHidden = password.type === 'password';
    password.type = isHidden ? 'text' : 'password';
    toggle.textContent = isHidden ? 'Hide' : 'Show';
    toggle.setAttribute('aria-pressed', isHidden ? 'true' : 'false');
  });

  form.addEventListener('submit', (ev) => {
    ev.preventDefault();
    message.textContent = '';
    message.className = '';

    // Basic validation
    const mail = email.value.trim();
    const pass = password.value;

    if (!mail) return showError('Please enter your email.');
    if (!validateEmail(mail)) return showError('Enter a valid email address.');
    if (!pass) return showError('Please enter your password.');

    // Demo authentication (replace with server call)
    if (mail === DEMO_EMAIL && pass === DEMO_PASS) {
      // store login state
      if (rememberCheckbox.checked) {
        localStorage.setItem('loggedIn', 'true');
        localStorage.setItem('userEmail', mail);
      } else {
        sessionStorage.setItem('loggedIn', 'true');
        sessionStorage.setItem('userEmail', mail);
      }

      showSuccess('Login successful — redirecting to homepage...');
      // short delay then navigate to homepage
      setTimeout(() => {
        window.location.href = 'home.html';
      }, 700);
    } else {
      showError('Invalid email or password.');
    }
  });

  function showError(text) {
    message.textContent = text;
    message.className = 'error';
  }

  function showSuccess(text) {
    message.textContent = text;
    message.className = 'success';
  }

  function validateEmail(v) {
    // simple email regex
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
  }
});